i_batch=0
i_model=2
i_mesh=1
mypath=joinpath(pwd())
repositorypath="D:\\work\\github\\LCMsim_v2.jl"

include(joinpath(repositorypath,"gui","lcmsim_v2_gui.jl"))